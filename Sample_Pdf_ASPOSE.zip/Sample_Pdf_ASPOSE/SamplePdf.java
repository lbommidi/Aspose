package com.createPdf;

import java.io.FileNotFoundException;
import java.util.Map;

import com.aspose.pdf.BorderInfo;
import com.aspose.pdf.BorderSide;
import com.aspose.pdf.Color;
import com.aspose.pdf.Document;
import com.aspose.pdf.FontRepository;
import com.aspose.pdf.FontStyles;
import com.aspose.pdf.Heading;
import com.aspose.pdf.HorizontalAlignment;
import com.aspose.pdf.MarginInfo;
import com.aspose.pdf.Page;
import com.aspose.pdf.PageNumberStamp;
import com.aspose.pdf.Row;
import com.aspose.pdf.Table;
import com.aspose.pdf.TextFragment;
import com.aspose.pdf.TextSegment;
import com.aspose.pdf.TextStamp;
import com.aspose.pdf.TocInfo;

public class SamplePdf {
	
	static String destination = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/GeneratedPdfs/sample12.pdf";

	public static void main(String[] args) throws FileNotFoundException, Exception {    	
    	createPdf();	
    }
	
	public static void createPdf(){
		
		Document pdfDoc = new Document();		
		pdfDoc.getPageInfo().setWidth(597.6);
		pdfDoc.getPageInfo().setHeight(842.4);
		pdfDoc.getPageInfo().getMargin().setLeft(37);
		pdfDoc.getPageInfo().getMargin().setRight(37);
		pdfDoc.getPageInfo().getMargin().setTop(130);
		pdfDoc.getPageInfo().getMargin().setBottom(95);
		
		Page page1 = pdfDoc.getPages().add();
		Table table = new Table();
		table.setDefaultCellBorder(new BorderInfo(BorderSide.All, 0.05f));
		table.setDefaultCellPadding(new MarginInfo(5,5,5,5));
		Row row1 = table.getRows().add();
		row1.getCells().add("column 1");
		row1.getCells().add("column 2");
		
		for(int i=0; i<50; i++){
			Row row = table.getRows().add();
			row.getCells().add("Item 1");
			row.getCells().add("Item 2");
		}
		page1.getParagraphs().add(table);
		
		Page page2 = pdfDoc.getPages().add();		
		TextFragment textFragment = new TextFragment();
    	textFragment.setText("This is a sample PDF generated using ASPOSE.");
		textFragment.getTextState().setFontSize(15);
		page2.getParagraphs().add(textFragment);
		
		createIndexPage(pdfDoc);
		addHeaderFooter(pdfDoc);
		
		pdfDoc.save(destination);
	}
	
	public static void addHeaderFooter(Document pdfDoc) {
		TextStamp header = new TextStamp("Header Text");
		header.setXIndent(37);
		header.setYIndent(750);
		header.getTextState().setFontSize(60);
		header.getTextState().setForegroundColor(Color.getBlue());
		
		TextStamp footer = new TextStamp("Footer Text");
		footer.setXIndent(37);
		footer.setYIndent(50);
		footer.getTextState().setFontSize(30);
		footer.getTextState().setForegroundColor(Color.getBlue());
		
		PageNumberStamp pageNumberStamp = new PageNumberStamp();
		pageNumberStamp.setBackground(true);
		pageNumberStamp.setFormat("#");
		pageNumberStamp.setBottomMargin(15);
		pageNumberStamp.setHorizontalAlignment(HorizontalAlignment.Center);
		pageNumberStamp.setStartingNumber(1);
		pageNumberStamp.getTextState().setFontSize(8);
		
		pdfDoc.processParagraphs();
		
		for (int Page_counter = 1; Page_counter <= pdfDoc.getPages().size(); Page_counter++) {
			pdfDoc.getPages().get_Item(Page_counter).addStamp(header);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(footer);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(pageNumberStamp);

		}
	}
	
	 public static void createIndexPage(Document pdfDoc){ 
	    	Page tocPage = pdfDoc.getPages().insert(1);			    	
			TocInfo tocInfo = new TocInfo();			
			TextFragment title = new TextFragment();
			title.setText("Table of Contents");
			title.getTextState().setFontSize(20);
			title.setMargin(new MarginInfo(0,30,0,0));
			title.getTextState().setUnderline(true);
			tocInfo.setTitle(title);
			tocPage.setTocInfo(tocInfo);
			
			//code for page numbers
			
	    } 
}
