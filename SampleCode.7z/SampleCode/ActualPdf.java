package com.createPdf;

import static java.util.Arrays.asList;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.aspose.pdf.BaseParagraph;
import com.aspose.pdf.BorderInfo;
import com.aspose.pdf.BorderSide;
import com.aspose.pdf.Cell;
import com.aspose.pdf.Color;
import com.aspose.pdf.Document;
import com.aspose.pdf.FloatingBox;
import com.aspose.pdf.Font;
import com.aspose.pdf.FontRepository;
import com.aspose.pdf.FontStyles;
import com.aspose.pdf.HeaderFooter;
import com.aspose.pdf.Heading;
import com.aspose.pdf.HorizontalAlignment;
import com.aspose.pdf.Image;
import com.aspose.pdf.ImageStamp;
import com.aspose.pdf.MarginInfo;
import com.aspose.pdf.Page;
import com.aspose.pdf.PageNumberStamp;
import com.aspose.pdf.Paragraphs;
import com.aspose.pdf.Row;
import com.aspose.pdf.Table;
import com.aspose.pdf.TextFragment;
import com.aspose.pdf.TextSegment;
import com.aspose.pdf.TextStamp;
import com.aspose.pdf.TocInfo;
import com.aspose.pdf.VerticalAlignment;
import com.aspose.pdf.drawing.Graph;
import com.aspose.pdf.drawing.Line;
import com.aspose.pdf.facades.FormattedText;
import com.aspose.pdf.facades.PdfFileEditor;

public class ActualPdf {
	
	public static final String headerImg = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/header.jpg";
    public static final String footerImg = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/footer.jpg";
    public static final String horizontalLine = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/horizontalLine.jpg";
    public static final String headingTab = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/titleHeader.jpg";
    public static final String cvrPageImg = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/coverPageImg.jpg";
    public static final String DEST = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/GeneratedPdfs/sample.pdf"; // pdf generates in this path
    public static final String TEST_REPORT = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Docs/TestReport.pdf";
    
    public static final String img1 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image1.jpg";
    public static final String img2 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image2.jpg";
    public static final String img3 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image3.jpg";
    public static final String img4 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image4.jpg";
    public static final String img5 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image5.jpg";
    public static final String img6 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image6.jpg";
    public static final String img7 = "C:/Users/dgamini/ELITE/Depot Report Tool/ASPOSE/Images/image7.jpg";
    
    static String engineModel = "LM2500";
	static String workOrderNum = "Z2CHU297756350";
	static String esn = "691-025";
	static String reportDate = "01-Oct-2018 Rev: 0";
	static String footerText = "LM2500 691-025";
	static String executiveSummaryData1 = "Teardown Inspection due to High B-Sump Temperature";
	
	//***************headings**********************
	static String introduction = "Introduction";
	static String preface = "Preface";
	static String incomingPhotos = "Incoming Photos";
	static String serviceBulletins = "Service Bulletins";
	static String parts = "Parts";
	static String testReport = "Test Report";
	static String additionalInfo = "Additional Information";
	static String masterPartsList = "Master Parts List";
	static String workscopePerModule = "Workscope per Module";
	static String findings = "Findings";
	static String nonConformingFindings = "Non-Conforming Findings";
	static String workscope = "Workscope";
	
	static List<String> bulletinTableHeadings =   asList("Bulletin#","Title","Level","Complied Date","Recomplied Date");
	static List<String> bulletinComplianceType =   asList("Recomplied","Verified","Complied");
	static List<String> partsTableHeadings =   asList("Transaction Type","Module","Part Number","Part Description","Total Qty.");
	static List<String> workscopeTable1 =   asList("Date:","Customer Name:","Work Order Number:","Engine Serial Number:");
	static List<String> workscopeTable2 = asList("MISSING AT INCOMING", "Part Description", "Part Number", "Quantity", "Disposition");
	static List<String> workscopeTable3 = asList("SUMP FLOW CHECK","Engine Module Unit", "Findings");
	static List<String> workscopeTable4 = asList("INCOMING BOROSCOPE FINDINGS","Engine Module Unit", "Results");
	static List<String> workscopeTable5 = asList("POST TEST BOROSCOPE INSPECTION","Engine Module Unit", "Results");
	static List<String> mwPartsHeadings = asList("PARTS DESCRIPTION","P/N REMOVED", "S/N REMOVED", "QTY", "DISPOSITION", "P/N INSTALLED", "S/N INSTALLED");
	static List<String> tocTitles = asList("Introduction", "Incoming Photos", "Workscope per Module", "Parts", "Service Bulletins", "Test Report", "Additional Information");
	
	static String executiveSummary = "Executive Summary";
	static String executiveSummaryText1 = "Reasons for being inducted into the Houston Service Center include:";
	static String executiveSummaryText2 = "Service bulletins accomplished during the visit include:";
	
	
	 //text
	static String prefaceText = "This is a shop visit report for a General Electric model LM2500 concerning engine serial number 691-025 prepared for Northland Power.\r\n\r\n"+
			"An executive summary on the following page identifies the primary reason for the visit with a brief list of service bulletins accomplished during the visit for quick reference."+  
			"The remainder of the report focuses on the findings discovered during the disassembly and inspection phase of repair and highlights the work scope required to address the findings and achieve the desired outcome.\r\n\r\n"+
			"Parts identified in the report are primarily non-consumable parts and are presented in part-tracking logs for each module. Each part-tracking log will name the parts removed and the parts installed by part number and serial number."+
			"A bill of materials has also been included to indicate new, serviceable or overhauled parts installed during the visit or parts repaired and reinstalled.\r\n\r\n"+
			"A separate schedule of applicable service bulletins has been included to indicate those that were accomplished this visit and others that were verified to have been previously accomplished.\r\n\r\n"+
			"If an engine test was directed by the work scope, a test report charting engine vibration data will be provided within this report. Engine parameter safety reading sheets will also be included in the test report."+
			"Any miscellaneous information not previously described in the module findings, work scope or supporting schedules is located in the additional information section.\r\n\r\n"+
			"Throughout the report, selected photos of the engine, its modules or its parts have been included at various stages of the visit. Incoming photos taken while the engine was being inducted are presented first."+
			"Photos taken during the disassembly and inspection phase appear with the findings for each module. Outgoing photos taken just prior to outbound shipping have also been included.\r\n\r\n"+ 
			"All activities described in this report, including any repairs performed by outside service vendors, have been performed in accordance with the applicable GEK 99418.";
	
	static String bulletinText = "The information in this report utilizes sources believed to be reliable. The accuracy, adequacy, completeness or timeliness of such information cannot, however be guaranteed. Neither GE, its suppliers of information, nor its officers, directors, the employees and agents shall be responsible for any errors or omissions or the result obtained from the use of the information in this report.";
	
    static Map<String, String> cvrPageData = new LinkedHashMap<String, String>();
    static List<LinkedHashMap<String, String>> execSummaryBulletins = new ArrayList<LinkedHashMap<String, String>>();
    static List<LinkedHashMap<String, String>> incomingPhotosList = new ArrayList<LinkedHashMap<String, String>>();
    static List<LinkedHashMap<String, String>> bulletinsList = new ArrayList<LinkedHashMap<String, String>>();
    static List<List<String>> partsTable = new ArrayList<List<String>>();
    //engine workscope data 
    static List<String> workscopeTable1Data =   asList("27-09-2018","NorthLand Power","Z2CHU297756350","691-025");
    static String ewText = "The LM2500 Gas Turbine identified by ESN 691-025, property of NorthLand Power, was delivered to the Houston Service Center"
			+ "due to B-Sump temperature.  The engine was removed from its shipping container, disassembled and visually inspected.  Upon its removal"
			+ " from the shipping container, missing parts and shipped loose inspections were completed.  A borescope inspect and a sump flow"
			+ " check were also conducted as directed by the workscope.  Findings are indicated below.\n\n";
    static List<LinkedHashMap<String, String>> workscopeTable2Data = new ArrayList<LinkedHashMap<String, String>>();
    static List<LinkedHashMap<String, String>> workscopeTable3Data = new ArrayList<LinkedHashMap<String, String>>();
    static List<LinkedHashMap<String, String>> workscopeTable4Data = new ArrayList<LinkedHashMap<String, String>>();
    static List<LinkedHashMap<String, String>> workscopeTable5Data = new ArrayList<LinkedHashMap<String, String>>();
    static List<String> modulesList = asList("CFF","HPCS", "HPCR");
    static String findingsData = "1. Some external piping had dents and scores";
    static String nonConformingFindingsData = "1. Chip detectors and screens had some contamination, positive for bearing M50 and M50Nil metal repaired";
    static String workscopeData = "1. Accepted for continued time";
    static String mwText = "The LM2500 Gas Turbine identified by ESN 691-025, property of NorthLand Power, was delivered to the Houston Service Center"
			+ "due to B-Sump temperature.";  
    
    static List<List<String>> mwPartsData = new ArrayList<List<String>>();
    static Map<String, Integer> tocPageNum = new LinkedHashMap<String, Integer>();
    
    public static void main(String[] args) {    	
    	createPdf();	
    }
    
    public static void createPdf(){
    	
    	Document pdfDoc = new Document();		
		pdfDoc.getPageInfo().setWidth(597.6);
		pdfDoc.getPageInfo().setHeight(842.4);
		pdfDoc.getPageInfo().getMargin().setLeft(37);
		pdfDoc.getPageInfo().getMargin().setRight(37);
		pdfDoc.getPageInfo().getMargin().setTop(175);
		pdfDoc.getPageInfo().getMargin().setBottom(95);
		
		cvrPageData.put("Engine S/N","691-025");
		cvrPageData.put("Engine Model","LM-2500");
		cvrPageData.put("Engine Manufacturer","GE Aircraft Engines, Marine and Industrial");
		cvrPageData.put("Project Number","7274852");
		cvrPageData.put("Engine Configuration","Gas Generator");
		cvrPageData.put("Work Order Number","Z2CHU297756350");
		cvrPageData.put("Customer Name","NorthLand Power");
		cvrPageData.put("Reason for Shop Visit","Teardown Inspection due to High B-Sump Temperature");
		cvrPageData.put("Time Since New","Not Provided");
		cvrPageData.put("Total Starts/Cycles Since New","Not Provided");
		cvrPageData.put("Time Since Last Visit","Not Provided");
		cvrPageData.put("Arrival Date","01-Sep-2018");
		cvrPageData.put("Induction Date","05-Sep-2018");
		cvrPageData.put("Performance Acceptance Test","27-Sep-2018");
		cvrPageData.put("Completion Date","03-Oct-2018");
		
		LinkedHashMap<String, String> bulletinMap1 = new LinkedHashMap<String, String>();
		bulletinMap1.put("bulletinNum","LM2500-IND-277");
		bulletinMap1.put("bulletinTitle","Improved Compressor Rotor Air Duct");
		LinkedHashMap<String, String> bulletinMap2 = new LinkedHashMap<String, String>();
		bulletinMap2.put("bulletinNum","LM2500-IND-398");
		bulletinMap2.put("bulletinTitle","IGB Spline Forward Oil Dam Insert and Spline Adapter Introduction");
		execSummaryBulletins.add(bulletinMap1);
		execSummaryBulletins.add(bulletinMap2);
		
		LinkedHashMap<String, String> incPhotosMap1 = new LinkedHashMap<String, String>();
		incPhotosMap1.put("img",img1);	
		incPhotosMap1.put("caption","caption1");
		LinkedHashMap<String, String> incPhotosMap2 = new LinkedHashMap<String, String>();
		incPhotosMap2.put("img",img2);
		incPhotosMap2.put("caption","caption2");
		LinkedHashMap<String, String> incPhotosMap3 = new LinkedHashMap<String, String>();
		incPhotosMap3.put("img",img3);
		incPhotosMap3.put("caption","caption3");
		LinkedHashMap<String, String> incPhotosMap4 = new LinkedHashMap<String, String>();
		incPhotosMap4.put("img",img4);
		incPhotosMap4.put("caption","caption4");
		LinkedHashMap<String, String> incPhotosMap5 = new LinkedHashMap<String, String>();
		incPhotosMap5.put("img",img5);
		incPhotosMap5.put("caption","caption5");
		LinkedHashMap<String, String> incPhotosMap6 = new LinkedHashMap<String, String>();
		incPhotosMap6.put("img",img6);
		incPhotosMap6.put("caption","caption6");
		LinkedHashMap<String, String> incPhotosMap7 = new LinkedHashMap<String, String>();
		incPhotosMap7.put("img",img7);
		incPhotosMap7.put("caption","caption7");
		
		incomingPhotosList.add(incPhotosMap1);
		incomingPhotosList.add(incPhotosMap2);
		incomingPhotosList.add(incPhotosMap3);
		incomingPhotosList.add(incPhotosMap4);
		incomingPhotosList.add(incPhotosMap5);
		incomingPhotosList.add(incPhotosMap6);
		incomingPhotosList.add(incPhotosMap7);
		
		
		LinkedHashMap<String, String> bulletinInfoMap1 = new LinkedHashMap<String, String>();
		bulletinInfoMap1.put("bulletinNum","LM2500-IND-277");
		bulletinInfoMap1.put("complianceType","complied");
		bulletinInfoMap1.put("title","Improved Compressor Rotor Air Duct");
		bulletinInfoMap1.put("level","DEPOT");
		bulletinInfoMap1.put("compliedDate","14/07/2018");
		bulletinInfoMap1.put("recompliedDate","");		
		bulletinsList.add(bulletinInfoMap1);
		
		LinkedHashMap<String, String> bulletinInfoMap2 = new LinkedHashMap<String, String>();
		bulletinInfoMap2.put("bulletinNum","LM2500-IND-398");
		bulletinInfoMap2.put("complianceType","recomplied");
		bulletinInfoMap2.put("title","IGB Spline Forward Oil Dam");
		bulletinInfoMap2.put("level","DEPOT");
		bulletinInfoMap2.put("compliedDate","21/08/2018");
		bulletinInfoMap2.put("recompliedDate","29/08/2018");	
		
		bulletinsList.add(bulletinInfoMap2);
		
		LinkedHashMap<String, String> bulletinInfoMap3 = new LinkedHashMap<String, String>();
		bulletinInfoMap3.put("bulletinNum","LM2500-IND-435");
		bulletinInfoMap3.put("complianceType","verified");
		bulletinInfoMap3.put("title","IGB Spline Forward Oil Dam");
		bulletinInfoMap3.put("level","DEPOT");
		bulletinInfoMap3.put("compliedDate","15/09/2018");
		bulletinInfoMap3.put("recompliedDate","");		
		bulletinsList.add(bulletinInfoMap3);
		
		partsTable = asList(
		            asList("Vendor Services","CRF","9174M68G01-RP","BEARING NO.4, CDP SEAL, REPAIR","4"),
		            asList("Vendor Services","CRF","9174M68G03-SRP","HOSING, BALL BEARING, NO.4, CDP","1"),
		            asList("Material","S1N","9174M68G01","NUT, CHANNEL","2"),
		            asList("Material","S1N","9174M64579","RIVET","6"),
		            asList("Vendor Services","CRF","9174M68G01-RP","BEARING NO.4, CDP SEAL, REPAIR","4"),
		            asList("Vendor Services","CRF","9174M68G03-SRP","HOSING, BALL BEARING, NO.4, CDP","1"),
		            asList("Material","S1N","9174M68G01","NUT, CHANNEL","2"),
		            asList("Material","S1N","9174M64579","RIVET","6"),
		            asList("Vendor Services","CRF","9174M68G01-RP","BEARING NO.4, CDP SEAL, REPAIR","4"),
		            asList("Vendor Services","CRF","9174M68G03-SRP","HOSING, BALL BEARING, NO.4, CDP","1"),
		            asList("Material","S1N","9174M68G01","NUT, CHANNEL","2"),
		            asList("Material","S1N","9174M64579","RIVET","6"),
		            asList("Vendor Services","CRF","9174M68G01-RP","BEARING NO.4, CDP SEAL, REPAIR","4"),
		            asList("Vendor Services","CRF","9174M68G03-SRP","HOSING, BALL BEARING, NO.4, CDP","1"),
		            asList("Material","S1N","9174M68G01","NUT, CHANNEL","2"),
		            asList("Material","S1N","9174M64579","RIVET","6")
		            
		          );
		
		LinkedHashMap<String, String> workscopeTable2Map1 = new LinkedHashMap<String, String>();
		workscopeTable2Map1.put("partDesc","Natural Gas Nozzle");
		workscopeTable2Map1.put("partNum","L21045P11");
		workscopeTable2Map1.put("qty","2");
		workscopeTable2Map1.put("disposition","Order Replacement");				
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		workscopeTable2Data.add(workscopeTable2Map1);
		
		
		LinkedHashMap<String, String> workscopeTable3Map1 = new LinkedHashMap<String, String>();
		workscopeTable3Map1.put("engModUnit","Compressor Front Frame1");
		workscopeTable3Map1.put("findings","Serviceable1");
		workscopeTable3Data.add(workscopeTable3Map1);
		workscopeTable3Data.add(workscopeTable3Map1);
		workscopeTable3Data.add(workscopeTable3Map1);
		
		LinkedHashMap<String, String> workscopeTable3Map2 = new LinkedHashMap<String, String>();
		workscopeTable3Map2.put("engModUnit","Compressor Front Frame2");
		workscopeTable3Map2.put("findings","Serviceable2");
		LinkedHashMap<String, String> workscopeTable3Map3 = new LinkedHashMap<String, String>();
		workscopeTable3Map3.put("engModUnit","Compressor Front Frame3");
		workscopeTable3Map3.put("findings","Serviceable3");
		workscopeTable4Data.add(workscopeTable3Map1);
		workscopeTable4Data.add(workscopeTable3Map2);
		workscopeTable4Data.add(workscopeTable3Map3);
		
		
		workscopeTable5Data = workscopeTable3Data;
		
		mwPartsData = asList(
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"),
	            asList("FRONT FRAME","L21372G06","FIA00490","1","INSPECTED","L21372G06","FIA00490"));
		
		
		//createCoverPage(pdfDoc);
		//yet to be implemented
		//createIntroduction(pdfDoc);
		//createIncomingPhotos(pdfDoc);
		createEngWorkscope(pdfDoc);
		//createModuleWorkscope(pdfDoc);
		//createParts(pdfDoc);
		//createServiceBulletins(pdfDoc);		
		//createTestReport(pdfDoc);
		createAdditionalInfo(pdfDoc);
		
		
		createIndexPage(pdfDoc);
		addHeader(pdfDoc);
		addFooter(pdfDoc);
		
		//concatenatePDF(pdfDoc, TEST_REPORT);
		
		pdfDoc.save(DEST);
    	
    }
    
    public static void createCoverPage(Document pdfDoc){
    	Page page = pdfDoc.getPages().add();
    	String report = "Houston Service Center Report";
    	Table table = createTable(new BorderInfo(BorderSide.None, 0));
    	table.setColumnWidths("523");
    	Row row1 = table.getRows().add();
    	TextFragment textFragment = createTextFragment(report, FontRepository.findFont("Arial"),12,FontStyles.Bold, true, Color.getWhite());
    	Cell cell1 = createCellWithText(row1, textFragment);
    	cell1.setBackgroundColor(Color.fromArgb(24,147,193));
    	cell1.setAlignment(HorizontalAlignment.Center);
    	
    	Row row2 = table.getRows().add();
    	Image img = createImage(cvrPageImg, 210);
    	Cell cell2 = createCellWithImage(row2, img);  
    	cell2.setBorder(new BorderInfo(BorderSide.Box, 0.05f));
    	page.getParagraphs().add(table);
    	
    	//data table
    	Table dataTable = createTable(new BorderInfo(BorderSide.None, 0));
    	dataTable.setColumnWidths("262 261");
    	dataTable.setBorder(new BorderInfo(BorderSide.Box, 0.05f));
    	dataTable.setDefaultCellPadding(new MarginInfo(5,2,2,2));
    	dataTable.setMargin(new MarginInfo(0,0,0,30));
    	int counter = 1;
    	
    	for (Map.Entry<String,String> entry : cvrPageData.entrySet()){

    		Row row = dataTable.getRows().add(); 
    		if(counter %2 != 0)
    			row.setBackgroundColor(Color.getLightGray());
    		TextFragment text1 = createTextFragment(entry.getKey(), FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
    		TextFragment text2 = createTextFragment(entry.getValue(), FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
    	    createCellWithText(row, text1);
    	    createCellWithText(row, text2);
    	    counter++;
    	}
    	page.getParagraphs().add(dataTable);
            
    }
    
    
    
    public static void createIntroduction(Document pdfDoc){
    	//introduction    	
    	Page page1 = pdfDoc.getPages().add(); 
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(introduction, pageNum);
    	TextStamp textStamp = createTextStamp(introduction, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 200, 400);
    	page1.addStamp(textStamp);
    	
    	//preface 
    	Page page2 = pdfDoc.getPages().add();
    	
    	createHeadingTab(page2, headingTab, preface);
    	addNewLine(page2, 1);
    	TextFragment text1 = createTextFragment(prefaceText, FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
    	text1.getTextState().setLineSpacing(5);// default
    	text1.setHorizontalAlignment(HorizontalAlignment.Justify);
    	page2.getParagraphs().add(text1);
    	
    	//Executive summary
    	Page page3 = pdfDoc.getPages().add();
    	createHeadingTab(page3, headingTab, executiveSummary);
    	addNewLine(page3, 1);
    	TextFragment text2 = createTextFragment(executiveSummaryText1, FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
    	text2.setMargin(new MarginInfo(20,0,0,0));
    	page3.getParagraphs().add(text2);
    	
    	TextSegment bullet = createBullet(); 
    	Heading bulletData = createBulletData(bullet, executiveSummaryData1, 11);
    	bulletData.setMargin(new MarginInfo(40,30,0,15));
		page3.getParagraphs().add(bulletData);
		
		TextFragment text3 = createTextFragment(executiveSummaryText2, FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
    	text3.setMargin(new MarginInfo(20,0,0,0));
    	page3.getParagraphs().add(text3);
    	
    	Table table = createTable(new BorderInfo(BorderSide.None, 0));
    	table.setColumnWidths("140 343");
    	table.setMargin(new MarginInfo(40,0,0,15));
    	for(int i= 0; i<execSummaryBulletins.size(); i++){
    		String bulletinNum = execSummaryBulletins.get(i).get("bulletinNum");
    		String bulletinTitle = execSummaryBulletins.get(i).get("bulletinTitle");
    		TextFragment text4 = createTextFragment(bulletinNum, FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
    		TextFragment text5 = createTextFragment(bulletinTitle, FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
        	
    		Row row =  table.getRows().add();
    		Cell cell1 = createCellWithText(row, text4);
    		Cell cell2 = createCellWithText(row, text5);
    		
    	}
    	page3.getParagraphs().add(table);
    	//test bullets    	    			        
    	/*TextSegment bullet = createBullet();    	
    	for(int i=0; i<10; i++){
    		Heading bulletData = createBulletData(bullet, String.valueOf(i));
    		page3.getParagraphs().add(bulletData);
    	}*/
    	
    	
    	//test
    	/*Page page3 = pdfDoc.getPages().add();
    	TextFragment test = new TextFragment();
    	TextSegment seg = new TextSegment();
    	seg.setText("hello");
    	seg.getTextState().setFontStyle(FontStyles.Regular);
    	test.getSegments().add(seg);
    	TextSegment seg1 = new TextSegment();
    	seg1.setText("bold hello");
    	seg1.getTextState().setFontStyle(FontStyles.Bold);
    	test.getSegments().add(seg1);
    	page3.getParagraphs().add(test);*/
    }
    
    public static void createIncomingPhotos(Document pdfDoc){    	
    	//Incoming photos
    	Page page1 = pdfDoc.getPages().add();    	
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(incomingPhotos, pageNum);
    	TextStamp textStamp = createTextStamp(incomingPhotos, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 165, 400);
    	page1.addStamp(textStamp);
    	displayImages(pdfDoc, incomingPhotos, incomingPhotosList);    	
    }
    
    public static void createEngWorkscope(Document pdfDoc){
    	Page page1 = pdfDoc.getPages().add(); 
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(workscopePerModule, pageNum);
    	TextStamp textStamp = createTextStamp(workscopePerModule, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 120, 400);
    	page1.addStamp(textStamp);
    	
    	Page page2 = pdfDoc.getPages().add();
    	createWorkscopeTable(page2, "Engine(ENG)");
    	TextFragment text= createTextFragment(ewText, FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
    	text.getTextState().setHorizontalAlignment(HorizontalAlignment.Justify);
    	text.getTextState().setLineSpacing(3);
    	page2.getParagraphs().add(text);
    	
    	//missing at incoming
    	if(workscopeTable2Data.size()>0){
    		Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
        	table.setColumnWidths("183 140 55 145");
        	createEngineWorkscopeTable(page2, table, workscopeTable2, workscopeTable2Data, 4);
    	}
    	//sump flow check
    	if(workscopeTable3Data.size()>0){
    		Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
        	table.setColumnWidths("183 340");
        	createEngineWorkscopeTable(page2, table, workscopeTable3, workscopeTable3Data, 2);
    	}
    	//incoming boroscope findings
    	if(workscopeTable4Data.size()>0){
    		Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
        	table.setColumnWidths("183 340");
        	createEngineWorkscopeTable(page2, table, workscopeTable4, workscopeTable4Data, 2);
    	}
    	//post test boroscope inspection
    	if(workscopeTable5Data.size()>0){
    		Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
        	table.setColumnWidths("183 340");
        	table.setKeptWithNext(true);
        	table.setBroken(true);
        	
        	createEngineWorkscopeTable(page2, table, workscopeTable5, workscopeTable5Data, 2);
    	}
    	//findings
    	if(findingsData != null){    		
        	createHeadingAndParagraph(page2, findings, findingsData);
    	}
    	// non conforming findings
    	if(nonConformingFindingsData != null){    		
        	createHeadingAndParagraph(page2, nonConformingFindings, nonConformingFindingsData);
    	}    	
    }
    
    public static void createModuleWorkscope(Document pdfDoc){
    	
    //commenting out multiple modules code
    	//for(int i=0; i< modulesList.size(); i++){
    		Page page = pdfDoc.getPages().add();
	    	//createWorkscopeTable(page, modulesList.get(i));
    		
    		createWorkscopeTable(page, modulesList.get(0));
	    	//description of scope performed
	    	if(mwText != null){
		    	TextFragment text= createTextFragment(mwText, FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
		    	text.getTextState().setHorizontalAlignment(HorizontalAlignment.Justify);
		    	text.getTextState().setLineSpacing(3);
		    	page.getParagraphs().add(text);
	    	}
	    	//findings
	    	if(findingsData != null){    		
	        	createHeadingAndParagraph(page, findings, findingsData);
	    	}
	    	// non conforming findings
	    	if(nonConformingFindingsData != null){    		
	        	createHeadingAndParagraph(page, nonConformingFindings, nonConformingFindingsData);
	    	}
	    	// workscope data
	    	if(workscopeData != null){    		
	        	createHeadingAndParagraph(page, workscope, workscopeData);
	    	}
	    	//parts
	    	if(mwPartsData.size()>0){
		    	Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
		    	table.setColumnWidths("123 80 70 30 70 80 70");
		    	//table.setMargin(new MarginInfo(0,15,0,0));
		    	Row row1 = table.getRows().add();
		    	row1.setBackgroundColor(Color.getLightGray());
		    	
		    	for(int j=0;j< mwPartsHeadings.size(); j++){
		    		TextFragment text= createTextFragment(mwPartsHeadings.get(j), FontRepository.findFont("Arial"),10,FontStyles.Bold, false, null);
		        	createCellWithText(row1, text);
		    	}
		    	for(List<String> listRow : mwPartsData){        	
		        	Row row = table.getRows().add();
		        	for(String element: listRow){
		        		TextFragment text= createTextFragment(element, FontRepository.findFont("Arial"),9,FontStyles.Regular, false, null);
			        	createCellWithText(row, text);
		        	}        	
		        }		    	
		    	page.getParagraphs().add(table);
	    	}
	    	
	    	if(incomingPhotosList.size()>0){
	    		//displayImages(pdfDoc, modulesList.get(i), incomingPhotosList);
	    		displayImages(pdfDoc, modulesList.get(0), incomingPhotosList);
	    	}
    	//}    	
    }
    
    public static void createParts(Document pdfDoc){
    	Page page1 = pdfDoc.getPages().add();
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(parts, pageNum);
    	TextStamp textStamp = createTextStamp(parts, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 250, 400);
    	page1.addStamp(textStamp);
    	
    	Page page2 = pdfDoc.getPages().add();
    	
    	createHeadingTab(page2, headingTab, masterPartsList);
    	
    	Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
    	table.setMargin(new MarginInfo(0,0,0,0));
    	table.setColumnWidths("100 100 100 188 35");
    	table.setRepeatingRowsCount(1);
    	Row row1 = table.getRows().add();
    	row1.setBackgroundColor(Color.fromArgb(106, 179, 222));
    	for(int i=0;i< partsTableHeadings.size(); i++){
    		TextFragment text= createTextFragment(partsTableHeadings.get(i), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
        	createCellWithText(row1, text);
    	}
    	for(List<String> listRow : partsTable){        	
        	Row row = table.getRows().add();
        	for(String element: listRow){
        		TextFragment text= createTextFragment(element, FontRepository.findFont("Arial"),9,FontStyles.Regular, false, null);
	        	createCellWithText(row, text);
        	}       	
        }   	
    	page2.getParagraphs().add(table);
    }
    
    public static void createServiceBulletins(Document pdfDoc){
    	Page page1 = pdfDoc.getPages().add();
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(serviceBulletins, pageNum);
    	TextStamp textStamp = createTextStamp(serviceBulletins, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 165, 400);
    	page1.addStamp(textStamp);
    	
    	Page page2 = pdfDoc.getPages().add();
    	
    	Table table1 = createTable(new BorderInfo(BorderSide.All, 0.05f));
    	table1.setColumnWidths("140");
    	table1.setLeft(420);
    	table1.setMargin(new MarginInfo(0,0,0,15));
    	for(int i=0;i<bulletinComplianceType.size();i++){
    		Row row = table1.getRows().add();
        	TextFragment text= createTextFragment(bulletinComplianceType.get(i), FontRepository.findFont("Arial"),9,FontStyles.Bold, false, null);
        	Cell cell = createCellWithText(row, text);
        	if(bulletinComplianceType.get(i).equalsIgnoreCase("Recomplied")){
        		cell.setBackgroundColor(Color.getGreenYellow());
        	}
        	if(bulletinComplianceType.get(i).equalsIgnoreCase("Verified")){
        		cell.setBackgroundColor(Color.getYellow());
        	}
        	if(bulletinComplianceType.get(i).equalsIgnoreCase("Complied")){
        		cell.setBackgroundColor(Color.getOrange());
        	}

    	}
    	page2.getParagraphs().add(table1);
    	
    	
    	Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
    	table.setColumnWidths("110 193 80 70 70");
    	table.setMargin(new MarginInfo(0,15,0,0));
    	Row row1 = table.getRows().add();
    	row1.setBackgroundColor(Color.getLightSkyBlue());
    	
    	for(int i=0;i< bulletinTableHeadings.size(); i++){
    		TextFragment text= createTextFragment(bulletinTableHeadings.get(i), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
        	createCellWithText(row1, text);
    	}
    	String complianceType ="";
    	for(int i= 0; i<bulletinsList.size(); i++){
    		Row row =  table.getRows().add();
    		for (Map.Entry<String,String> entry : bulletinsList.get(i).entrySet()){
    			if(entry.getKey().equals("complianceType")){
    				System.out.println("Inside if, compliance type:"+entry.getValue());
    				complianceType = entry.getValue();
    			}else{
	    			String text = entry.getValue();
	    			TextFragment textFrag = createTextFragment(text, FontRepository.findFont("Arial"),9,FontStyles.Regular, false, null);
	    			Cell cell = createCellWithText(row, textFrag);
	    			if(entry.getKey().equals("compliedDate") || (entry.getKey().equals("recompliedDate") && entry.getValue().length()>0)){
	    				if(complianceType.equalsIgnoreCase("Recomplied")){
	    					cell.setBackgroundColor(Color.getGreenYellow());
	    				}
	    				if(complianceType.equalsIgnoreCase("Verified")){
	    					cell.setBackgroundColor(Color.getYellow());
	    				}
	    				if(complianceType.equalsIgnoreCase("Complied")){
	    					cell.setBackgroundColor(Color.getOrange());
	    				}
	    			}
    			}
    		}    		
    	}   	
    	page2.getParagraphs().add(table); 
    	
    	TextFragment text1 = createTextFragment(bulletinText, FontRepository.findFont("Arial"),8,FontStyles.Regular, false, null);
    	text1.getTextState().setLineSpacing(3);// default
    	text1.setHorizontalAlignment(HorizontalAlignment.Justify);
    	page2.getParagraphs().add(text1);
    }   
    
    public static void createTestReport(Document pdfDoc){
    	Page page1 = pdfDoc.getPages().add();
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(testReport, pageNum);
    	TextStamp textStamp = createTextStamp(testReport, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 200, 400);
    	page1.addStamp(textStamp);
    }
    
    public static void createAdditionalInfo(Document pdfDoc){ 
    	Page page1 = pdfDoc.getPages().add();
    	int pageNum = pdfDoc.getPages().size()+1;
    	tocPageNum.put(additionalInfo, pageNum);
    	TextStamp textStamp = createTextStamp(additionalInfo, FontRepository.findFont("Arial"), 35, FontStyles.Regular, false, null, 140, 400);
    	page1.addStamp(textStamp);
    }
    
    public static void createIndexPage(Document pdfDoc){ 
    	Page tocPage = pdfDoc.getPages().insert(1);
    	
		// Create object to represent TOC information    	
		TocInfo tocInfo = new TocInfo();
		TextFragment title = createTextFragment("Table of Contents", FontRepository.findFont("Arial"),20,FontStyles.Bold, false, null);
		title.setMargin(new MarginInfo(0,30,0,0));
		title.getTextState().setUnderline(true);
		tocInfo.setTitle(title);
		tocPage.setTocInfo(tocInfo);

		System.out.println("Total pages:"+pdfDoc.getPages().size());
		System.out.println(tocPageNum);
		
		for (Map.Entry<String,Integer> entry : tocPageNum.entrySet()){ 
			
			Heading heading = new Heading(1);
			TextSegment segment = new TextSegment();
			segment.setText(entry.getKey());
			
			heading.setTocPage(tocPage);
			heading.getSegments().add(segment);			
			heading.setDestinationPage(pdfDoc.getPages().get_Item(entry.getValue()));				
			heading.setMargin(new MarginInfo(30,15,30,0));
			tocPage.getParagraphs().add(heading);
		}
		
		/*for (int i = 0; i < 2; i++) {
			Heading heading = new Heading(1);
			TextSegment segment = new TextSegment();
			heading.setTocPage(tocPage);
			heading.getSegments().add(segment);
			heading.setDestinationPage(pdfDoc.getPages().get_Item(i+1));
			
			//heading.getTextState().setFontSize(12);
			//heading.getTextState().setFontStyle(FontStyles.Bold);
			heading.getTextState().setLineSpacing(15);
			// Destination page
			//heading.setTop(pdfDoc.getPages().get_Item(i +1).getRect().getHeight());
			// Destination coordinate
			segment.setText(tocTitles.get(i));
			// Add heading to page containing TOC
			tocPage.getParagraphs().add(heading);
		}*/
    } 
    
    public static void concatenatePDF(Document pdfDoc1, String TEST_REPORT){
    	Document pdfDoc2 = new Document(TEST_REPORT);
    	pdfDoc1.getPages().add(pdfDoc2.getPages());
    	//return pdfDoc1;
    }
    
    //generic methods
    
    public static Table createTable(BorderInfo borderInfo){
    	Table table = new Table();
    	table.setMargin(new MarginInfo(0,15,0,15));
    	table.setDefaultCellPadding(new MarginInfo(2,2,2,2));
    	table.setDefaultCellBorder(borderInfo);    	
    	return table;
    }
    
    public static Cell createCellWithText(Row row, TextFragment textFragment){
    	Cell cell = row.getCells().add();    	
    	cell.getParagraphs().add(textFragment);
    	return cell;
    }
    
    public static Cell createCellWithImage(Row row, Image image){
    	Cell cell = row.getCells().add();    	
    	cell.getParagraphs().add(image);
    	return cell;
    }
        
    public static TextFragment createTextFragment(String text,Font font,float fontSize, int fontStyle, boolean color, Color textColor){
    	TextFragment textFragment = new TextFragment();
    	textFragment.setText(text);
		textFragment.getTextState().setFont(font);
		textFragment.getTextState().setFontSize(fontSize);
		textFragment.getTextState().setFontStyle(fontStyle);		
		if(color){
			textFragment.getTextState().setForegroundColor(textColor);
		}
    	return textFragment;
    }
    
    public static Image createImage(String filePath, double height){
    	Image image = new Image();
    	image.setFile(filePath); // can be changed to buffered image or input stream
    	if(height>0){
    		image.setFixHeight(height);
    	}
    	return image;
    }
    
    public static TextStamp createTextStamp(String text,Font font,float fontSize, int fontStyle,boolean color, Color textColor, double xIndent, double yIndent){
    	TextStamp textStamp = new TextStamp(text);
		textStamp.setXIndent(xIndent);
		textStamp.setYIndent(yIndent);
		textStamp.getTextState().setFont(font);
		textStamp.getTextState().setFontSize(fontSize);
		textStamp.getTextState().setFontStyle(fontStyle);
		if(color){
			textStamp.getTextState().setForegroundColor(textColor);
		}
    	return textStamp;
    }
    
    public static ImageStamp createImageStamp(String filePath, double xIndent, double yIndent, double height, double width ){
    	ImageStamp imageStamp = new ImageStamp(filePath);
		imageStamp.setXIndent(xIndent);
		imageStamp.setYIndent(yIndent);
		imageStamp.setHeight(height);
		imageStamp.setWidth(width);
    	return imageStamp;
    }
    
    public static void createHeadingTab(Page page, String imagePath, String text){
    	ImageStamp imageStamp = createImageStamp(imagePath, 37, 650, 25, 523);
    	page.addStamp(imageStamp);
    	
    	TextStamp textStamp = createTextStamp(text, FontRepository.findFont("Arial"), 13, FontStyles.Bold, true, Color.getWhite(),40, 655);    	
    	page.addStamp(textStamp);
    	addNewLine(page,3);
    	
    }
    
    public static void addNewLine(Page page, int lines){
    	TextFragment newLine = new TextFragment(" ");
    	for(int i=0; i<lines; i++){
    		page.getParagraphs().add(newLine);
    	}
    }

    public static TextSegment createBullet(){
    	TextSegment seg = new TextSegment("•");
    	seg.getTextState().setFontSize(12);
    	seg.getTextState().setForegroundColor(Color.getBlack()); 
    	return seg;
    }
    
    public static Heading createBulletData(TextSegment seg, String text, float fontSize){
    	Heading bulletData = new Heading(1);
    	bulletData.setInList(true);
    	bulletData.setStartNumber(1);
    	bulletData.setUserLabel(seg);
    	bulletData.setAutoSequence(true);
		bulletData.setText(text);
		bulletData.getTextState().setFontSize(fontSize);
		return bulletData;
    }
    public static void createHeadingAndParagraph(Page page, String heading, String data){
    	TextFragment textFrag1= createTextFragment(heading, FontRepository.findFont("Arial"),12,FontStyles.Bold, false, null);
		textFrag1.getTextState().setUnderline(true);
		textFrag1.setMargin(new MarginInfo(0,5,0,10));
		page.getParagraphs().add(textFrag1);
		TextFragment textFrag2= createTextFragment(data, FontRepository.findFont("Arial"),11,FontStyles.Regular, false, null);
		textFrag2.getTextState().setHorizontalAlignment(HorizontalAlignment.Justify);
		textFrag2.getTextState().setLineSpacing(3);
		textFrag2.setMargin(new MarginInfo(20,0,0,0));
    	page.getParagraphs().add(textFrag2);
    }
    
    public static void createEngineWorkscopeTable(Page page, Table table, List<String> headings, List<LinkedHashMap<String, String>> data, int colspan){
    	Row rowHeader = table.getRows().add();
    	rowHeader.setBackgroundColor(Color.getLightGray());
    	TextFragment textheader= createTextFragment(headings.get(0), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
    	Cell cellHeader = createCellWithText(rowHeader, textheader);
    	cellHeader.setColSpan(colspan);
    	cellHeader.setAlignment(HorizontalAlignment.Center);
    	
    	Row row1 = table.getRows().add();
    	row1.setBackgroundColor(Color.fromArgb(106, 179, 222));
    	for(int i=1;i< headings.size(); i++){
    		TextFragment textFrag= createTextFragment(headings.get(i), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
        	createCellWithText(row1, textFrag);
    	}
    	
    	for(int i= 0; i<data.size(); i++){
    		Row row =  table.getRows().add();
    		for (Map.Entry<String,String> entry : data.get(i).entrySet()){   	    		
	    		TextFragment textFrag = createTextFragment(entry.getValue(), FontRepository.findFont("Arial"),9,FontStyles.Regular, false, null);
	    		createCellWithText(row, textFrag);
	    	
    		}
    	}  
    	//table.setKeptWithNext(true);
    	table.setBroken(true);    	
    	table.setRepeatingRowsCount(2);
    	page.getParagraphs().add(table);
    }
    public static void createWorkscopeTable(Page page, String header){
	    Table table = createTable(new BorderInfo(BorderSide.All, 0.05f));
		table.setColumnWidths("230 293");
		table.setMargin(new MarginInfo(0,15,0,0));
		Row row1 = table.getRows().add();
		row1.setBackgroundColor(Color.fromArgb(21,117,172));
		TextFragment textheader= createTextFragment(header, FontRepository.findFont("Arial"),12,FontStyles.Bold, true, Color.getWhite());
		Cell cellheader =createCellWithText(row1, textheader);
		cellheader.setColSpan(2);
		cellheader.setAlignment(HorizontalAlignment.Center);
		page.getParagraphs().add(table); 
	
		for(int i=0;i< workscopeTable1.size(); i++){
			Row row = table.getRows().add();
			if(i%2==0){
				row.setBackgroundColor(Color.getLightGray());
			}
			TextFragment text= createTextFragment(workscopeTable1.get(i), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
	    	createCellWithText(row, text);
	    	TextFragment textData= createTextFragment(workscopeTable1Data.get(i), FontRepository.findFont("Arial"),11,FontStyles.Bold, false, null);
	    	createCellWithText(row, textData);
		}
    }
    
    public static void displayImages(Document pdfDoc, String headingText, List<LinkedHashMap<String, String>> photosList){
    	//display photos
    	Page page = pdfDoc.getPages().add();    	
    	createHeadingTab(page, headingTab, headingText);
    	Table table = createTable(new BorderInfo(BorderSide.None, 0));
    	table.setColumnWidths("260 260");
    	table.setDefaultCellBorder(new BorderInfo(BorderSide.All, 0.1F));
    	table.setDefaultCellPadding(new MarginInfo(10,10,10,10));    	
    	int count = 0;
    	boolean addTableFlag = false;
    	
    	for(int i=0;i < (int) Math.ceil(photosList.size()/2.0);i++){
    		System.out.println("Inside for "+count);
    		//create new page once 4 images are added to a page
    		if(count> 0 && count%4 == 0){
    			page = pdfDoc.getPages().add();
    			createHeadingTab(page, headingTab, headingText);
    			table = createTable(new BorderInfo(BorderSide.None, 0));
    	    	table.setColumnWidths("260 260");
    	    	table.setDefaultCellBorder(new BorderInfo(BorderSide.All, 0.1F));
    	    	table.setDefaultCellPadding(new MarginInfo(10,10,10,10));
    		}
    		//adding new row for image
    		Row rowImage = table.getRows().add();
    		rowImage.setFixedRowHeight(200);
    		//adding new row for caption
    		Row rowCaption = table.getRows().add();
    		
    		//adding cell1
    		if(count<photosList.size()){
    			Image img = createImage(photosList.get(count).get("img"), 0);
    			createCellWithImage(rowImage, img);
    			TextFragment text= createTextFragment(photosList.get(count).get("caption"), FontRepository.findFont("Arial"),10,FontStyles.Regular, false, null);
	        	createCellWithText(rowCaption, text);
    			count = count +1;
    		}
    		//adding cell2
    		if(count<photosList.size()){   
    			Image img = createImage(photosList.get(count).get("img"), 0);
    			createCellWithImage(rowImage, img);
    			TextFragment text= createTextFragment(photosList.get(count).get("caption"), FontRepository.findFont("Arial"),10,FontStyles.Regular, false, null);
	        	createCellWithText(rowCaption, text);
    			//check if 4 images got added to the page
    			if(count%4 ==3){
    				//flag for adding table to the page
    				addTableFlag = true;
    			}
    			count = count +1;
    		}
    		//adding table if images = 4 or end of images 
    		if(addTableFlag ||count == photosList.size()){   
    			System.out.println("Inside if ");
    			addTableFlag = false;
    	    	page.getParagraphs().add(table);
    		}
    	}
    }
    /*
    public static Heading createBullet(){
    	TextSegment seg = new TextSegment("•");
    	seg.getTextState().setFontSize(12);
    	seg.getTextState().setForegroundColor(Color.getBlack()); 
    	
    	Heading bulletValue = new Heading(1);
    	
    	bulletValue.setInList(true);
    	bulletValue.setStartNumber(1); 
    		    
    	bulletValue.setUserLabel(seg);
    	bulletValue.setAutoSequence(true);
    	return bulletValue;
    }*/
    
   /* public static void createHeadingTab(Page page, String imagePath, String text){
    	Image image = createImage(imagePath,25);
    	image.setFixWidth(523);
    	page.getParagraphs().add(image);
    	
    	TextStamp textStamp = createTextStamp(text, FontRepository.findFont("Arial"), 13, FontStyles.Bold, true, Color.getRed(),40, 640);    	
    	page.addStamp(textStamp);
    }*/
    
    /*public static void addHeader(Document pdfDoc) {

		ImageStamp imageStamp1 = new ImageStamp(headerImg);
		imageStamp1.setBackground(true);
		imageStamp1.setXIndent(37);
		imageStamp1.setYIndent(715);
		imageStamp1.setHeight(90);
		imageStamp1.setWidth(523);

		TextStamp textStamp1 = new TextStamp("Customer Name: Northland Power");
		// set properties of the stamp
		textStamp1.setXIndent(37);
		textStamp1.setYIndent(700);
		textStamp1.getTextState().setFontSize(11);
		textStamp1.getTextState().setFontStyle(FontStyles.Bold);
		textStamp1.getTextState()
				.setForegroundColor(Color.fromArgb(4, 97, 151));

		TextStamp textStamp2 = new TextStamp(
				"Service Center Location: Houston, TX");
		// set properties of the stamp
		textStamp2.setXIndent(360);
		textStamp2.setYIndent(700);
		textStamp2.getTextState().setFontSize(11);
		textStamp2.getTextState().setFontStyle(FontStyles.Bold);
		textStamp2.getTextState().setForegroundColor(Color.fromArgb(4, 97, 151));
		
		TextStamp textStamp3 = new TextStamp(engineModel);
		textStamp3.setXIndent(428);
		textStamp3.setYIndent(787);
		textStamp3.getTextState().setFontSize(9);
		textStamp3.getTextState().setFontStyle(FontStyles.Bold);
		textStamp3.getTextState().setForegroundColor(Color.getWhite());
		
		TextStamp textStamp4 = new TextStamp(workOrderNum);
		textStamp4.setXIndent(428);
		textStamp4.setYIndent(766);
		textStamp4.getTextState().setFontSize(9);
		textStamp4.getTextState().setFontStyle(FontStyles.Bold);
		textStamp4.getTextState().setForegroundColor(Color.getWhite());
		
		TextStamp textStamp5 = new TextStamp(esn);
		textStamp5.setXIndent(428);
		textStamp5.setYIndent(745);
		textStamp5.getTextState().setFontSize(9);
		textStamp5.getTextState().setFontStyle(FontStyles.Bold);
		textStamp5.getTextState().setForegroundColor(Color.getWhite());
		
		TextStamp textStamp6 = new TextStamp(reportDate);
		textStamp6.setXIndent(428);
		textStamp6.setYIndent(723);
		textStamp6.getTextState().setFontSize(9);
		textStamp6.getTextState().setFontStyle(FontStyles.Bold);
		textStamp6.getTextState().setForegroundColor(Color.getWhite());
		
		ImageStamp imageStamp2 = new ImageStamp(horizontalLine);
		imageStamp2.setBackground(true);
		imageStamp2.setXIndent(37);
		imageStamp2.setYIndent(693);
		imageStamp2.setHeight(5);
		imageStamp2.setWidth(523);
	
		Graph graph1 = new Graph(520, 2);
		float[] posArr = new float[] { 0, 2, 520, 2 };
		Line line = new	Line(posArr);
		//line.getGraphInfo().setColor(com.aspose.pdf.Color.fromArgb(4,118,225));
		line.getGraphInfo().setColor(com.aspose.pdf.Color.getRed());
		graph1.getShapes().add(line);
		

		for (int Page_counter = 1; Page_counter <= pdfDoc.getPages().size(); Page_counter++) {
			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp1);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp1);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp2);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp3);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp4);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp5);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp6);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp2);
		}
	}
	 
	public static Document addFooter(Document pdfDoc) {

		ImageStamp imageStamp = new ImageStamp(footerImg);
		imageStamp.setBackground(true);
		imageStamp.setXIndent(37);
		imageStamp.setYIndent(66);
		imageStamp.setHeight(23);
		imageStamp.setWidth(523);

		String footerInfo = "PROPRIETARY INFORMATION NOTICE:  The information contained in this document and any documents attached hereto is privileged and disclosed in confidence. It is the property of General Electric Company and shall not be used, disclosed to others or reproduced without the express written consent of General Electric Company.  If consent is given for reproduction in whole or in part, this notice shall appear on any such reproduction, in whole or in part.  The information contained in this document may also be controlled by the U.S. export control laws.  Unauthorized export or re-export is prohibited.";
		
		FormattedText formattedFooter = new FormattedText("PROPRIETARY INFORMATION NOTICE:  The information contained in this document and any documents attached hereto is privileged and disclosed in confidence.  It is the property of General");
		// add new text line to FormattedText
		formattedFooter.addNewLineText("Electric Company and shall not be used,disclosed to others or reproduced without the express written consent of General Electric Company. If consent is given for reproduction in whole or in part,");
		formattedFooter.addNewLineText("this notice shall appear on  any such reproduction, in whole or in part.  The information contained in this  document may also be controlled by the U.S. export control laws. Unauthorized export or ");
		formattedFooter.addNewLineText("re-export is prohibited.");

		TextStamp textStamp1 = new TextStamp(formattedFooter);
		// set properties of the stamp
		textStamp1.setXIndent(37);
		textStamp1.setYIndent(37);
		textStamp1.getTextState().setFontSize(6);
		textStamp1.getTextState().setHorizontalAlignment(HorizontalAlignment.Justify);

		TextStamp textStamp2 = new TextStamp(footerText);
		// set properties of the stamp
		textStamp2.setXIndent(265);
		textStamp2.setYIndent(72);
		textStamp2.getTextState().setFontSize(10);
		textStamp2.getTextState().setFontStyle(FontStyles.Bold);
		textStamp2.getTextState().setForegroundColor(Color.getWhite());
		textStamp2.getTextState().setHorizontalAlignment(HorizontalAlignment.Center);
		
		PageNumberStamp pageNumberStamp = new PageNumberStamp();
		// whether the stamp is background
		pageNumberStamp.setBackground(true);
		pageNumberStamp.setFormat("#");
		pageNumberStamp.setBottomMargin(15);
		pageNumberStamp.getTextState().setFontStyle(FontStyles.Regular);
		pageNumberStamp.setHorizontalAlignment(HorizontalAlignment.Center);
		pageNumberStamp.setStartingNumber(1);
		pageNumberStamp.getTextState().setFontSize(8);

		// add stamp to particular page
		pdfDoc.getPages().get_Item(1).addStamp(pageNumberStamp);
		for (int Page_counter = 1; Page_counter <= pdfDoc.getPages().size(); Page_counter++) {
			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp1);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp2);
			pdfDoc.getPages().get_Item(Page_counter).addStamp(pageNumberStamp);

		}
		return pdfDoc;

	}*/
    
	
    	public static void addHeader(Document pdfDoc) {

    		ImageStamp imageStamp1 = createImageStamp(headerImg, 37, 715, 90, 523);
    		TextStamp textStamp1 = createTextStamp("Customer Name: Northland Power",FontRepository.findFont("Arial"),11,FontStyles.Bold,true, Color.fromArgb(4, 97, 151), 37, 700);
    		TextStamp textStamp2 = createTextStamp("Service Center Location: Houston, TX",FontRepository.findFont("Arial"),11,FontStyles.Bold,true, Color.fromArgb(4, 97, 151), 360, 700);
    		TextStamp textStamp3 = createTextStamp(engineModel,FontRepository.findFont("Arial"),9,FontStyles.Bold,true, Color.getWhite(), 428, 787);
    		TextStamp textStamp4 = createTextStamp(workOrderNum,FontRepository.findFont("Arial"),9,FontStyles.Bold,true, Color.getWhite(), 428, 766);
    		TextStamp textStamp5 = createTextStamp(esn,FontRepository.findFont("Arial"),9,FontStyles.Bold,true, Color.getWhite(), 428, 745);
    		TextStamp textStamp6 = createTextStamp(reportDate,FontRepository.findFont("Arial"),9,FontStyles.Bold,true, Color.getWhite(), 428, 723);
    		ImageStamp imageStamp2 = createImageStamp(horizontalLine, 37, 693, 5, 523); 
    	
    		for (int Page_counter = 1; Page_counter <= pdfDoc.getPages().size(); Page_counter++) {
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp1);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp1);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp2);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp3);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp4);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp5);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp6);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp2);
    		}
    	}
    	 
    	public static Document addFooter(Document pdfDoc) {

    		ImageStamp imageStamp = createImageStamp(footerImg, 37, 66, 23, 523);
    		
    		FormattedText formattedFooter = new FormattedText("PROPRIETARY INFORMATION NOTICE:  The information contained in this document and any documents attached hereto is privileged and disclosed in confidence.  It is the property of General");
    		// add new text line to FormattedText
    		formattedFooter.addNewLineText("Electric Company and shall not be used,disclosed to others or reproduced without the express written consent of General Electric Company. If consent is given for reproduction in whole or in part,");
    		formattedFooter.addNewLineText("this notice shall appear on  any such reproduction, in whole or in part.  The information contained in this  document may also be controlled by the U.S. export control laws. Unauthorized export or ");
    		formattedFooter.addNewLineText("re-export is prohibited.");
    		TextStamp textStamp1 = new TextStamp(formattedFooter);
    		// set properties of the stamp
    		textStamp1.setXIndent(37);
    		textStamp1.setYIndent(37);
    		textStamp1.getTextState().setFontSize(6);
    		textStamp1.getTextState().setHorizontalAlignment(HorizontalAlignment.Justify);
    		

    		TextStamp textStamp2 = createTextStamp(footerText,FontRepository.findFont("Arial"),10,FontStyles.Bold,true, Color.getWhite(), 265, 72);
    		textStamp2.getTextState().setHorizontalAlignment(HorizontalAlignment.Center);
    		
    		
    		PageNumberStamp pageNumberStamp = new PageNumberStamp();
    		// whether the stamp is background
    		pageNumberStamp.setBackground(true);
    		pageNumberStamp.setFormat("#");
    		pageNumberStamp.setBottomMargin(15);
    		pageNumberStamp.getTextState().setFontStyle(FontStyles.Regular);
    		pageNumberStamp.setHorizontalAlignment(HorizontalAlignment.Center);
    		pageNumberStamp.setStartingNumber(1);
    		pageNumberStamp.getTextState().setFontSize(8);

    		// add stamp to particular page
    		pdfDoc.getPages().get_Item(1).addStamp(pageNumberStamp);
    		for (int Page_counter = 1; Page_counter <= pdfDoc.getPages().size(); Page_counter++) {
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(imageStamp);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp1);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(textStamp2);
    			pdfDoc.getPages().get_Item(Page_counter).addStamp(pageNumberStamp);

    		}
    		return pdfDoc;

    	}

}
